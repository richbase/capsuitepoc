from flask import Flask, render_template, redirect, url_for
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField
from wtforms.validators import InputRequired, Email, Length

app = Flask(__name__)
app.config['SECRET_KEY'] = 'thisisasecret'
Bootstrap(app)



class LoginForm(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=4, max=25)])
    password = PasswordField('password', validators=[InputRequired(), Length(min=8, max=12)])
    remember = BooleanField('remember me')

class RegisterForm(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=4, max=25)])
    company = StringField('company', validators=[InputRequired(), Length(min=2, max=100)])
    email = StringField('email', validators=[InputRequired(), Length(min=8, max=50)])
    password = PasswordField('password', validators=[InputRequired(), Length(min=8, max=12)])
    confirm_password = PasswordField('confirm_password', validators=[InputRequired(), Length(max=8)])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    form = LoginForm()

    return render_template('login.html', form=form)

@app.route('/signin')
def signin():
    form = LoginForm()

    return render_template('signin.html', form=form)

@app.route('/register')
def register():
    form = LoginForm()

    return render_template('register.html', form=form)


if __name__ == '__main__':
    app.run(debug=True)
