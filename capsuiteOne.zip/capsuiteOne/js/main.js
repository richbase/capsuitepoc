$(document).ready(function () {
    $("#sticker").sticky({topSpacing:0});
    $('.nav-container').sticky({
        topSpacing:0,
        zIndex : 9999,
    });
})